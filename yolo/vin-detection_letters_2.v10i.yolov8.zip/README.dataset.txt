# vin-detection_letters_2 > 2022-02-22 8:43pm
https://universe.roboflow.com/kirill-sergeev/vin-detection_letters_2

Provided by a Roboflow user
License: Public Domain

